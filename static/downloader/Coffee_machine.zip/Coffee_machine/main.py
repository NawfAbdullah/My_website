from tkinter import * 
from tkinter import messagebox
from PIL import ImageTk,Image




#--------------------------------------Function-----------------------------------------------#

class Coffees:
	def __init__(self):
		self.UI()
		with open('resources.txt') as f:
			self.resources = f.readlines()

		self.name = "" 
		self.water= 0
		self.milk = 0
		self.coffee = 0 
		self.cost= 0
		self.total_water = int(self.resources[0])
		self.total_milk = int(self.resources[1])
		self.total_coffee = int(self.resources[2])
		self.root.mainloop()
		


	def latte_coffee(self):
		self.name="latte" 
		self.water=200
		self.milk=150 
		self.coffee=24 
		self.cost=2.5
		if self.enough_resources():
			self.payment()
		else:
			messagebox.showinfo(title="Sorry",message="No resource available :(")

	def espresso_coffee(self):
		self.name="espresso"
		self.water=50
		self.milk=0
		self.coffee=18
		self.cost=1.5
		if self.enough_resources():
			self.payment()
		else:
			messagebox.showinfo(title="Sorry",message="No resource available :(")
	    
	def cappuccino_coffee(self):
	    self.name="cappuccino"
	    self.water=250
	    self.milk=50
	    self.coffee=24
	    self.cost=3

	    if self.enough_resources():
	    	self.payment()
	    else:
	    	messagebox.showinfo(title="Sorry",message="No resource available :(")

	def enough_resources(self):
		return self.water<self.total_water and self.milk<self.total_milk and self.coffee<self.total_coffee
   	
	def payment(self):
		self.Cash_entry.delete(0,END)
		self.Cash_entry.insert(0,self.cost)
		self.pay_btn.config(state='normal')
		print(f'pay {self.cost}')

	def deliver_coffee(self):
		remaining_milk = self.total_milk-self.milk
		remaining_water = self.total_water-self.water
		remaining_coffee = self.total_coffee - self.coffee
		with open('resources.txt','w') as f:
			f.write(f'{remaining_water}\n{remaining_milk}\n{remaining_coffee}')
		self.generate_bill()

		messagebox.showinfo(title= "Coffee Delivered",message='Take your Coffeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee :)')


	def pay(self):
		if self.cost == float(self.Cash_entry.get()):
			self.deliver_coffee()
			self.pay_btn.config(state='disabled')

		elif self.cost<float(self.Cash_entry.get()):
			self.deliver_coffee()
			self.balance = float(self.Cash_entry.get()) - self.cost
			messagebox.showinfo(title='Balance',message=f'Balance: ₹{self.balance}')

		else:
			messagebox.showwarning(title = 'Not enough Cash',message=f'NO enough Cash the coffee costs ₹{self.cost}')

	def UI(self):
		self.root = Tk()
		self.root.title('Coffee machine')
		self.coffee_machine=  ImageTk.PhotoImage(Image.open('images/coffee_maker.jpg'))
		self.Machine_label = Label(image=self.coffee_machine)
		self.Machine_label.grid(row=0,column=0,columnspan=10,rowspan=10)

		self.latte_btn = Button(text="latte",command=self.latte_coffee)
		self.latte_btn.grid(row=4,column=6)

		self.espreso_btn = Button(text="espresso",command=self.espresso_coffee)
		self.espreso_btn.grid(row=3,column=3)

		self.cappuccino_btn = Button(text="cappuccino",command=self.cappuccino_coffee)
		self.cappuccino_btn.grid(row=3,column=6)

		self.Cash_entry = Entry(width=10,bg='grey',fg='lightgreen')
		self.Cash_entry.grid(row=4,column=3)

		self.pay_btn = Button(text = 'PAY',command=self.pay,state='disabled',bg='yellow',fg='blue',font=('Helvative',10,'bold'))
		self.pay_btn.grid(row=7,column=6)

	def mail_bill(self):
		pass

	
	def generate_bill(self):
		self.bill = f"{'-'*50}\n\t\tNawf Coffee Machine\t\t\n\n{'-'*50}\nname\t\tcost\tQty\n{self.name}\t{self.cost}\t1\n{'-'*50}\n\t\tThank You"
		print(self.bill)



coffees = Coffees()